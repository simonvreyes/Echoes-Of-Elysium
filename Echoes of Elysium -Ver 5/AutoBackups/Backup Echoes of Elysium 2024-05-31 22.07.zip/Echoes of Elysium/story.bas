﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=12.8
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: True
	#IncludeTitle: False
#End Region

Sub Process_Globals
	Dim Timer1 As Timer
End Sub

Sub Globals
	Dim displayText As String
	
	Dim currentIndex As Int
	
	Private Label1 As Label
	Private lblPressToContinue As Label
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("storyLayout")
	
	Timer1.Initialize("Timer1",95)
	
	displayText = "In the realm of Elysium, a land of magic and mystery, an ancient artifact known as the Echo Stone is believed to have created the realm of Elysium and is said to have the power to bring souls back to life. But the echo stone got corrupted through time because people are fighting to have it to satisfy their own desires. You, an adventurer, must save the world and destroy the echo stone. To do that you must progress in 3 different areas in the realm of Elysium and obtain an item from each area that will help you with your journey. Each area contains quests that you must accomplish in order to move on to the next area. You, a skilled adventurer, set out on a quest To uncover the secrets of the Echo Stone And decide its fate…"
	
	currentIndex = 0
	
	Timer1.Enabled = True
	Label1.Text = ""
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub lblPressToContinue_Click
	StartActivity(chooseChar)
	Activity.Finish
End Sub

Sub Timer1_Tick
	If currentIndex < displayText.Length Then
		Label1.Text = Label1.Text & displayText.CharAt(currentIndex)
		
		currentIndex = currentIndex + 1
	Else
		Timer1.Enabled = False
	End If
End Sub


Sub Activity_Touch (Action As Int, X As Float, Y As Float) As Boolean
	If Action = Activity.ACTION_DOWN Then
		Label1.Text = displayText
		Timer1.Enabled = False
	End If
	Return False
End Sub