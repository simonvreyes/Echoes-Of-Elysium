﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=12.8
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: True
	#IncludeTitle: False
#End Region

Sub Process_Globals
	
End Sub

Sub Globals
	Private btnQuit As Button
	Private btnStart As Button
	Private btnLoad As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("titleLayout")
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Private Sub btnStart_Click
	StartActivity(VolumePrompt)
	Activity.Finish
End Sub

Private Sub btnLoad_Click
	If Main.currentArea = 0  And Main.currentQuest = 0 Then
		MsgboxAsync("There is no saved progress, please play until you reach the first area","WARNING")
	Else If Main.currentArea = 1 And Main.currentQuest = 1 Then
		StartActivity(FirstAreaQ1)
		Activity.Finish
	Else If Main.currentArea = 1 And Main.currentQuest = 2 Then
		StartActivity(FirstAreaQ2)
		Activity.Finish
	End If
End Sub

Private Sub btnQuit_Click
	Msgbox2Async("Are you sure you want to quit?", "WARNING", "Yes", "Cancel", "", Null, False)
	Wait For Msgbox_Result (Result As Int)
	If Result = DialogResponse.POSITIVE Then
		ExitApplication
	End If
End Sub

Private Sub Activity_KeyPress (KeyCode As Int) As Boolean
	Return BackKey.handleKey(KeyCode)
End Sub
