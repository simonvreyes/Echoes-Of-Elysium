﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=12.8
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: True
	#IncludeTitle: False
#End Region

Sub Process_Globals

End Sub

Sub Globals
	Private btnReturn As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("firstAreaQ1Layout")
End Sub

Sub Activity_Resume
	Main.currentArea = 1
	Main.currentQuest = 1
End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub btnReturn_Click
	Msgbox2Async("Are you sure you want to return to the title page? Progress will be saved.", "CONFIRMATION", "Yes", "Cancel", "", Null, False)
	Wait For Msgbox_Result (Result As Int)
	If Result = DialogResponse.POSITIVE Then
		StartActivity(Title)
		Activity.Finish
	End If
End Sub

Private Sub Activity_KeyPress (KeyCode As Int) As Boolean
	Return BackKey.handleKey(KeyCode)
End Sub

