﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=12.8
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: True
	#IncludeTitle: False
#End Region

Sub Process_Globals
End Sub

Sub Globals
	Dim displayText1 As String
	Dim displayText2 As String
	Dim displayText3 As String
	Dim displayText4 As String
	Dim displayText5 As String
	Dim displayText6 As String
	Dim displayText7_1 As String
	Dim displayText7_2 As String
	
	
	Dim currentIndex As Int 
	Dim currentLabel As Label
	Dim currentDisplayText As String
	Dim currentDialogue As Int
	
	Private lblDialogueCharacter As Label
	Private lblDialoguePlayer As Label
	
	Private lblPlayerName As Label
	
	Private pnlDialogueCharacter As Panel
	Private pnlDialoguePlayer As Panel
	Private pnlChoices As Panel
	
	Private btnCryptogram As Button
	Private btnRiddle As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("firstAreaDialogueLayout")
	
	lblPlayerName.Text = Main.characterName
	Main.Timer1.Initialize("Timer1", 35)
    
	' Set the text to display
	displayText1 = "Halt, traveler. You have entered the Whispering Woods, a place of ancient magic and illusions. State your purpose."
	displayText2 = "I seek to navigate these woods and uncover the secrets they hold. My quest is to destroy the Echo Stone and save the realm of Elysium."
	displayText3 = "The Echo Stone... a relic of great power and great peril. Many have sought it, and many have been lost to its allure. But you... you wish to destroy it? Why should I believe you are any different from those who came before?"
	displayText4 = "I have seen the suffering the Echo Stone has caused. It must be destroyed to bring peace to Elysium."
	displayText5 = "Words are easily spoken, but actions reveal the truth. The Whispering Woods tests not only the mind but the heart. To proceed, you must solve one of our ancient puzzles. Choose wisely, for the path you take will determine your fate."
	displayText6 = "You face two paths. The first path challenges your wit with the Riddles of the Ancient, testing your ability to think and reason. The second path challenges your perception with the Cryptic Glyphs, testing your ability to see beyond the surface. Succeed, and you shall receive the Key of Insight, which unlocks the way to the Enigma of the Celestial Temple. Fail, and you shall be forever lost in these woods."
	displayText7_1 = "Very well. Prepare yourself for the Riddles of the Ancient. Answer correctly, and you may continue your journey. Fail, and you shall be lost in the illusions of this."
	displayText7_2 = "As you wish. The Cryptic Glyphs await you. Decipher their hidden messages, and the path shall be revealed. Fail, and you shall wander in darkness, never finding your way."
	
    
	currentIndex = 0
	currentLabel = lblDialogueCharacter
	currentDisplayText = displayText1
	currentDialogue = 0
	
	pnlDialoguePlayer.Visible = False
	pnlChoices.Visible = False

	' Start the Timer
	Main.Timer1.Enabled = True
    
	' Set the initial text of the label to empty
	lblDialogueCharacter.Text = ""
	lblDialoguePlayer.Text = ""
End Sub

Sub Activity_Resume
	
End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Sub Timer1_Tick
	' Check if there are more characters to display
	If currentIndex < currentDisplayText.Length Then
		' Add the next character to the label
		currentLabel.Text = currentLabel.Text & currentDisplayText.CharAt(currentIndex)
		' Move to the next character
		currentIndex = currentIndex + 1
	Else
		' Stop the Timer when all characters are displayed
		Main.Timer1.Enabled = False
	End If
End Sub

Sub Activity_Touch (Action As Int, X As Float, Y As Float) As Boolean
	If Action = Activity.ACTION_DOWN Then
		If Main.Timer1.Enabled Then
			currentLabel.Text = currentDisplayText
			Main.Timer1.Enabled = False
		Else
			Select Case currentDialogue
				Case 0
					currentDisplayText = displayText2
					dialoguePlayer
				Case 1
					currentDisplayText = displayText3
					dialogueCharacter
				Case 2
					currentDisplayText = displayText4
					dialoguePlayer
				Case 3
					currentDisplayText = displayText5
					dialogueCharacter
				Case 4
					currentDisplayText = displayText6
					dialogueCharacter
				Case 5
					pnlChoices.Visible = True
					Return False
				Case 6
					StartActivity(FirstAreaQ1)
					Activity.Finish
				Case 7
					StartActivity(FirstAreaQ2)
					Activity.Finish
			End Select

			newDialogue
		End If
	End If
	Return True
End Sub

Private Sub btnRiddle_Click
	currentDisplayText = displayText7_1
	currentLabel = lblDialogueCharacter
	currentDialogue = currentDialogue + 1
	pnlChoices.Visible = False
	pnlDialogueCharacter.Visible = True
	lblDialogueCharacter.Text = ""
	newDialogue
End Sub

Private Sub btnCryptogram_Click
	currentDisplayText = displayText7_2
	currentLabel = lblDialogueCharacter
	currentDialogue = currentDialogue + 2
	pnlChoices.Visible = False
	pnlDialogueCharacter.Visible = True
	lblDialogueCharacter.Text = ""
	newDialogue
End Sub

Private Sub newDialogue
	currentIndex = 0
	currentLabel.Text = ""
	Main.Timer1.Enabled = True
End Sub

Private Sub dialogueCharacter
	currentLabel = lblDialogueCharacter
	currentDialogue = currentDialogue + 1
	pnlDialogueCharacter.Visible = True
	pnlDialoguePlayer.Visible = False
	lblDialoguePlayer.Text = ""
End Sub

Private Sub dialoguePlayer
	currentLabel = lblDialoguePlayer
	currentDialogue = currentDialogue + 1
	pnlDialogueCharacter.Visible = False
	pnlDialoguePlayer.Visible = True
	lblDialogueCharacter.Text = ""
End Sub

Private Sub Activity_KeyPress (KeyCode As Int) As Boolean
	Return BackKey.handleKey(KeyCode)
End Sub
